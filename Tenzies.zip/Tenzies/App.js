import React from "react";
import "./tenzies.css";
import Die from "./Die";
import {nanoid} from "nanoid" 
import Confetti from "react-confetti";
export default function App(){
    const[dice,setDice]=React.useState(allNewDice)
    const[tenzies,setTenzies]=React.useState(false)//to represent whether th euser won the gam eor not
    //an affect thet runs every time the 'dice' state array changes
 
 //keeping two internal pieces of state to sync with each other is really a common reason to use the useEffect
 //.every() : method is look for a specific condition if every item in that array return true for that condition then .every()method returns true
 React.useEffect(()=>{
    //to end the game all the dice must be held and all have same value
    const allHeld=dice.every(die=>die.isHeld)//checking isHeld property
    const firstValue=dice[0].value;
    const allSameValue=dice.every(die=>die.value===firstValue);//to check all the values are same or not
    if(allHeld && allSameValue){
        setTenzies(true)
        
    }
  },[dice])


 function getNewDie(){
    var randomNumber=getRandomNumber(1,6);
    return({value:randomNumber,
        isHeld:false,
    id:nanoid()
}

    )
 }

    //function to generate a random number  btw the range(inclusive)
    function getRandomNumber(min,max){
        return Math.floor(Math.random()*(max-min+1))+min;
    }
    //to generate an array of random numbers
    function allNewDice(){
        var randomArray=[]
        for(var i=0;i<10;i++){
            // randomArray.push(Math.ceil(Math.random()*6)) //-an alternative way to generate random numbers
        
            //to check whether they are held or not,we convert them array  into a objects
           randomArray.push(getNewDie()) 
        }
        
        return randomArray;
    }
  
    
    const diceElements = dice.map(die=>
    <Die 
    key={die.id} 
    value={die.value}
    isHeld={die.isHeld}
    //in it passing anonymous fn  as a prop to die component
    holdDice={()=>holdDice(die.id)}
     />)
//updating rolldice to to not just roll all new dice,but instead to look though the existing dice
//to NOT role any that are are being Held--approach is it taking the olddice values and map it by taking each die and if it is held,keep it the same otherwise generate new die
   function rollDice(){
    //run only when they won't win the game
    if(!tenzies){
    setDice(oldDice=>oldDice.map(die=>{
        return die.isHeld?
        die:
        getNewDie()
    }))
   }
   else{
    //when they  win the game 
    setTenzies(false)
    setDice(allNewDice)
   }
   }
//the holdDice function to flip the 'isHeld' property on the object in the array that was clicked
//in it it takes the clicked die id,and traverse through the entire olddice array,the id which matches with the 
//clicked id will flip its value and the remaining dice will be placed as same using ternary operator

function holdDice(id){
    setDice(oldDice=>oldDice.map(die=>{
        return die.id===id?
        {...die,isHeld:!die.isHeld}:
        die
    }))
}
  
  
    return(
        <>
        <main>
            {/* conditionally rendering only when the tenzies true */}
            {tenzies && <Confetti/>}
            <h1 className="title">Tenzies</h1>
            <p className="instructions">Roll until all dice are the same .Click each die to freeze it as its Current value between rools.</p>
            <div className="dice-container">
          {diceElements}
        </div>
        <button 
        onClick={rollDice} 
        className="roll-button">
            {tenzies?"NewGame":"Roll"}
            </button>
        </main>
        </>
    )
}